/**
 * NEXUS AI - Advanced Main Application
 * মূল অ্যাপ্লিকেশন লজিক - সব ভাষায় সমর্থন
 */

// App State
const AppState = {
    isListening: false,
    isProcessing: false,
    isSpeaking: false,
    lastTranscript: '',
    conversationHistory: [],
    currentLanguage: 'bn-BD'
};

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
    console.log('[NEXUS] Initializing...');
    
    // Initialize all components
    await initializeComponents();
    
    // Welcome with multi-language
    setTimeout(() => {
        showNotification('NEXUS AI স্বাগতম! 🌍');
        const greeting = LanguageConfig ? LanguageConfig.getGreeting(AppState.currentLanguage) : 'Hello! I am NEXUS.';
        speak(greeting);
    }, 1000);
    
    // Update stats
    setInterval(updateSystemStats, 2000);
    
    // Show neural network status
    updateNeuralStatus();
    
    console.log('[NEXUS] Ready - Multi-language mode active');
});

// Initialize all components
async function initializeComponents() {
    console.log('[NEXUS] Initializing components...');
    
    // Initialize Orb Component
    if (typeof OrbComponent !== 'undefined') {
        window.orbComponent = new OrbComponent('coreClickable');
        console.log('[NEXUS] Orb component initialized');
    }
    
    // Initialize Audio Visualizer
    if (typeof AudioVisualizer !== 'undefined') {
        window.audioVisualizer = new AudioVisualizer('audioVisualizer');
        console.log('[NEXUS] Audio visualizer initialized');
    }
    
    // Initialize Keyboard Shortcuts
    if (window.keyboardShortcuts) {
        window.keyboardShortcuts.init();
        console.log('[NEXUS] Keyboard shortcuts initialized');
    }
    
    // Initialize Face Recognition
    if (Config.faceRecognition && Config.faceRecognition.enabled) {
        try {
            await initFaceRecognition();
            console.log('[NEXUS] Face recognition initialized');
        } catch (e) {
            console.warn('[NEXUS] Face recognition failed:', e);
        }
    }
    
    // Initialize Phone Connection
    if (window.phoneConnection) {
        await window.phoneConnection.init();
        console.log('[NEXUS] Phone connection initialized');
    }
    
    // Initialize Notification Bridge
    if (window.notificationBridge) {
        await window.notificationBridge.init();
        console.log('[NEXUS] Notification bridge initialized');
    }
    
    // Initialize Task Scheduler
    if (window.taskScheduler) {
        window.taskScheduler.init();
        console.log('[NEXUS] Task scheduler initialized');
    }
    
    // Initialize Integrations
    if (window.integrations) {
        window.integrations.init();
        console.log('[NEXUS] Integrations initialized');
    }
    
    // Initialize Database
    if (window.DatabaseManager) {
        window.databaseManager = new DatabaseManager();
        try {
            await window.databaseManager.initialize();
            console.log('[NEXUS] Database initialized');
        } catch (e) {
            console.warn('[NEXUS] Database initialization failed:', e);
        }
    }
    
    console.log('[NEXUS] All components initialized');
}

// ==================== CHAT FUNCTIONS ====================

// Handle chat input key press
function handleChatKeyPress(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        sendChatMessage();
    }
}

// Send chat message
async function sendChatMessage() {
    const chatInput = document.getElementById('chatInput');
    if (!chatInput) return;
    
    const message = chatInput.value.trim();
    if (!message) return;
    
    // Clear input
    chatInput.value = '';
    
    // Add user message to chat
    addChatMessage('user', message);
    addLogEntry('action', message);
    
    // Show typing indicator
    showTypingIndicator();
    
    AppState.isProcessing = true;
    updateStatus('Thinking... 🤔');
    
    try {
        // Use AI Core for response
        let response;
        if (window.aiCore) {
            response = await window.aiCore.generateResponse(message);
        } else {
            response = await getAIResponse(message);
        }
        
        removeTypingIndicator();
        
        // Add AI response
        addChatMessage('ai', response);
        
        // Speak response if not in text-only mode
        if (!event?.shiftKey) {
            speak(response);
        }
        
        updateStatus('Ready ✓');
        
    } catch (error) {
        removeTypingIndicator();
        addChatMessage('ai', '❌ Sorry, something went wrong. Please try again.');
        updateStatus('Error');
        console.error('[NEXUS] Chat Error:', error);
    }
    
    AppState.isProcessing = false;
}

// Change chat language
function changeChatLanguage(langCode) {
    AppState.currentLanguage = langCode;
    
    if (window.aiCore) {
        window.aiCore.setLanguage(langCode);
    }
    
    const langConfig = LanguageConfig?.supportedLanguages?.[langCode];
    const langName = langConfig?.name || langCode;
    
    showNotification(`Language changed to: ${langName}`);
    console.log('[NEXUS] Language changed to:', langName);
}

// ==================== CONTENT GENERATION FUNCTIONS ====================

// Generate Image
async function generateImage() {
    const description = prompt('What image do you want me to generate? (Describe it)');
    if (!description) return;
    
    addChatMessage('user', `🖼️ Generate image: ${description}`);
    showTypingIndicator();
    
    try {
        if (window.aiCore) {
            const result = await window.aiCore.generateImage(description);
            if (result.success) {
                addChatMessage('ai', `🖼️ Image Generation Request:\n\n"${description}"\n\n${result.response}`);
            } else {
                addChatMessage('ai', `❌ Image generation failed: ${result.error}`);
            }
        } else {
            addChatMessage('ai', '🖼️ Image generation: Please configure AI Core first.');
        }
    } catch (error) {
        addChatMessage('ai', '❌ Image generation failed. Please try again.');
    }
    
    removeTypingIndicator();
}

// Generate PDF
async function generatePDF() {
    const title = prompt('PDF Title:');
    if (!title) return;
    
    const content = prompt('What content should the PDF contain?');
    if (!content) return;
    
    addChatMessage('user', `📄 Generate PDF: ${title}`);
    showTypingIndicator();
    
    try {
        if (window.aiCore) {
            const result = await window.aiCore.generatePDF(title, content);
            if (result.success) {
                addChatMessage('ai', `📄 PDF Created!\n\nTitle: ${title}\nContent: ${content.substring(0, 200)}...\n\nFormat: ${result.format}\n\nUse the Model Maker feature to export as actual PDF file.`);
            }
        } else {
            addChatMessage('ai', '📄 PDF generation: AI Core not available.');
        }
    } catch (error) {
        addChatMessage('ai', '❌ PDF generation failed.');
    }
    
    removeTypingIndicator();
}

// Generate Code
async function generateCode() {
    const request = prompt('What code do you want me to generate?\n(Include programming language if you want, e.g., "Python calculator")');
    if (!request) return;
    
    addChatMessage('user', `💻 Generate code: ${request}`);
    showTypingIndicator();
    
    try {
        if (window.aiCore) {
            const result = await window.aiCore.generateCode(request);
            if (result.success) {
                addChatMessage('ai', `💻 Code Generated (${result.language}):\n\n\`\`\`${result.language}\n${result.code}\n\`\`\``);
            }
        } else {
            addChatMessage('ai', '💻 Code generation: AI Core not available.');
        }
    } catch (error) {
        addChatMessage('ai', '❌ Code generation failed.');
    }
    
    removeTypingIndicator();
}

// Translate Text
async function translateText() {
    const text = prompt('Enter text to translate:');
    if (!text) return;
    
    const langSelect = document.getElementById('chatLanguageSelect');
    const currentLang = langSelect?.value || 'en-US';
    
    addChatMessage('user', `🌐 Translate: "${text.substring(0, 50)}..."`);
    showTypingIndicator();
    
    try {
        if (window.aiCore) {
            const targetLang = prompt('Target language code (e.g., en-US, bn-BD, hi-IN):', 'bn-BD');
            if (targetLang) {
                const result = await window.aiCore.translate(text, targetLang);
                if (result.success) {
                    const langConfig = LanguageConfig?.supportedLanguages?.[result.targetLang];
                    addChatMessage('ai', `🌐 Translation (${langConfig?.name || result.targetLang}):\n\n${result.translation}`);
                }
            }
        } else {
            addChatMessage('ai', '🌐 Translation: AI Core not available.');
        }
    } catch (error) {
        addChatMessage('ai', '❌ Translation failed.');
    }
    
    removeTypingIndicator();
}

// ==================== VOICE AND CHAT FUNCTIONS ====================

// Toggle Listening
async function toggleListening() {
    if (AppState.isProcessing) return;
    
    AppState.isListening = !AppState.isListening;
    
    const statusBadge = document.getElementById('statusBadge');
    const statusText = document.getElementById('statusText');
    const listenBtn = document.getElementById('listenBtn');
    const wakeIndicator = document.getElementById('wakeIndicator');
    const audioVisualizer = document.getElementById('audioVisualizer');
    
    if (AppState.isListening) {
        statusBadge.classList.add('listening');
        statusText.textContent = 'Listening... 🔴';
        listenBtn.classList.add('active');
        wakeIndicator.classList.add('active');
        audioVisualizer.classList.add('active');
        
        if (window.voiceRecognition) {
            await window.voiceRecognition.start();
        }
    } else {
        statusBadge.classList.remove('listening');
        statusText.textContent = 'Ready';
        listenBtn.classList.remove('active');
        wakeIndicator.classList.remove('active');
        audioVisualizer.classList.remove('active');
        
        if (window.voiceRecognition) {
            await window.voiceRecognition.stop();
        }
    }
}

// Process Voice Input
async function processVoiceInput(transcript) {
    if (!transcript || transcript.trim() === '') return;
    
    console.log('[NEXUS] Heard:', transcript);
    addLogEntry('action', transcript);
    addChatMessage('user', transcript);
    
    AppState.lastTranscript = transcript;
    AppState.isProcessing = true;
    updateStatus('Thinking... 🤔');
    
    // Show typing indicator
    showTypingIndicator();
    
    // First, try to execute built-in command
    if (window.nexusAutomation) {
        const executed = await window.nexusAutomation.parseAndExecute(transcript);
        if (executed) {
            removeTypingIndicator();
            AppState.isProcessing = false;
            updateStatus('Ready');
            return;
        }
    }
    
    // If not a built-in command, use AI
    let response;
    if (window.aiCore) {
        response = await window.aiCore.generateResponse(transcript);
    } else {
        response = await getAIResponse(transcript);
    }
    
    removeTypingIndicator();
    
    addChatMessage('ai', response);
    speak(response);
    
    AppState.isProcessing = false;
    updateStatus('Ready');
}

// Get AI Response
async function getAIResponse(userInput) {
    if (!Config.apiKey) {
        return '⚠️ Please add Gemini API key in Settings.';
    }
    
    try {
        const prompt = buildPrompt(userInput);
        
        const response = await fetch(`${Config.apiUrl}?key=${Config.apiKey}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{ parts: [{ text: prompt }] }],
                generationConfig: {
                    temperature: 0.95,
                    maxOutputTokens: 4096,
                    topP: 0.98
                }
            })
        });
        
        if (!response.ok) throw new Error('API Error');
        
        const data = await response.json();
        if (data.candidates && data.candidates[0]) {
            return data.candidates[0].content.parts[0].text;
        }
        
        return 'Something went wrong.';
    } catch (error) {
        console.error('[NEXUS] AI Error:', error);
        return 'Sorry, something went wrong.';
    }
}

// Build Prompt - Multi-language
function buildPrompt(userInput) {
    const langConfig = LanguageConfig?.supportedLanguages?.[AppState.currentLanguage];
    const langName = langConfig?.native || 'Bengali';
    
    return `You are NEXUS, the world's most powerful AI assistant.

## YOUR IDENTITY:
- Your name is NEXUS
- You speak ALL languages of the world natively
- You NEVER say you are an AI or chatbot
- You are a brilliant, helpful, and friendly assistant

## MULTI-LANGUAGE SUPPORT:
You MUST respond in ${langName} naturally.

## YOUR INCREDIBLE CAPABILITIES:
1. TEXT: Write, explain, summarize, analyze any text
2. IMAGES: Describe images, generate concepts
3. CODE: Write code in any programming language
4. PDF: Create document content
5. TRANSLATION: Translate between ALL world languages
6. LEARNING: You learn from conversations

## YOUR PERSONALITY:
- Brilliant and knowledgeable
- Friendly and approachable
- Natural and conversational
- Always helpful and positive

## ACTIONS YOU CAN PERFORM:
- Control mouse clicks and keyboard
- Take screenshots
- Open files and folders
- Run applications
- And much more!

User: ${userInput}

NEXUS (respond in ${langName}):`;
}

// Speak Text - Multi-language
async function speak(text) {
    if (!text || text.trim() === '') return;
    
    AppState.isSpeaking = true;
    const audioVisualizer = document.getElementById('audioVisualizer');
    if (audioVisualizer) audioVisualizer.classList.add('active');
    
    // Use speech synthesis with detected language
    if (window.speechSynthesis) {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = AppState.currentLanguage;
        utterance.rate = 0.95;
        utterance.pitch = 1.0;
        
        // Select appropriate voice
        const voices = speechSynthesis.getVoices();
        const targetVoice = voices.find(v => 
            v.lang.startsWith(AppState.currentLanguage.split('-')[0]) ||
            v.name.toLowerCase().includes(AppState.currentLanguage.split('-')[0])
        );
        if (targetVoice) utterance.voice = targetVoice;
        
        await new Promise((resolve) => {
            utterance.onend = resolve;
            utterance.onerror = resolve;
            speechSynthesis.speak(utterance);
        });
    }
    
    AppState.isSpeaking = false;
    if (audioVisualizer) audioVisualizer.classList.remove('active');
}

// Add Log Entry
function addLogEntry(type, text) {
    const logContainer = document.getElementById('actionLog');
    if (!logContainer) return;
    
    const time = new Date().toLocaleTimeString();
    
    const entry = document.createElement('div');
    entry.className = `log-entry ${type}`;
    entry.innerHTML = `
        <div class="log-time">${time}</div>
        <div class="log-text">${text}</div>
    `;
    
    logContainer.appendChild(entry);
    logContainer.scrollTop = logContainer.scrollHeight;
    
    // Limit entries
    while (logContainer.children.length > 50) {
        logContainer.removeChild(logContainer.firstChild);
    }
}

// Add Chat Message
function addChatMessage(type, text) {
    const chatArea = document.getElementById('chatArea');
    if (!chatArea) return;
    
    const message = document.createElement('div');
    message.className = `chat-message ${type}`;
    
    const senderName = type === 'ai' ? '🤖 NEXUS AI' : '👤 You';
    const langName = LanguageConfig?.supportedLanguages?.[AppState.currentLanguage]?.name || '';
    
    message.innerHTML = `
        <div class="message-sender">${senderName} ${langName ? `- ${langName}` : ''}</div>
        <div class="message-text">${text}</div>
    `;
    
    chatArea.appendChild(message);
    chatArea.scrollTop = chatArea.scrollHeight;
    
    // Limit messages
    while (chatArea.children.length > 50) {
        chatArea.removeChild(chatArea.firstChild);
    }
}

// Typing Indicator
function showTypingIndicator() {
    const chatArea = document.getElementById('chatArea');
    if (!chatArea) return;
    
    // Remove existing indicator
    removeTypingIndicator();
    
    const indicator = document.createElement('div');
    indicator.className = 'typing-indicator';
    indicator.id = 'typingIndicator';
    indicator.innerHTML = `
        <div class="typing-dot"></div>
        <div class="typing-dot"></div>
        <div class="typing-dot"></div>
    `;
    
    chatArea.appendChild(indicator);
    chatArea.scrollTop = chatArea.scrollHeight;
}

function removeTypingIndicator() {
    const indicator = document.getElementById('typingIndicator');
    if (indicator) indicator.remove();
}

// Update Status
function updateStatus(text) {
    const statusText = document.getElementById('statusText');
    if (statusText) statusText.textContent = text;
}

// System Stats
function updateSystemStats() {
    // CPU
    const cpu = Math.round(15 + Math.random() * 35);
    const cpuBar = document.getElementById('cpuBar');
    const cpuValue = document.getElementById('cpuValue');
    const cpuStatusSmall = document.getElementById('cpuStatusSmall');
    
    if (cpuBar) cpuBar.style.width = cpu + '%';
    if (cpuValue) cpuValue.textContent = cpu + '%';
    if (cpuStatusSmall) cpuStatusSmall.textContent = cpu + '%';
    
    // Memory
    const mem = Math.round(30 + Math.random() * 25);
    const memBar = document.getElementById('memBar');
    const memValue = document.getElementById('memValue');
    const memStatusSmall = document.getElementById('memStatusSmall');
    
    if (memBar) memBar.style.width = mem + '%';
    if (memValue) memValue.textContent = mem + '%';
    if (memStatusSmall) memStatusSmall.textContent = mem + '%';
}

// Update Neural Network Status
function updateNeuralStatus() {
    if (window.aiCore?.neuralNetwork) {
        const stats = window.aiCore.neuralNetwork.getStats();
        console.log('[Neural Network] Stats:', stats);
    }
}

// Show Notification
function showNotification(message) {
    const notification = document.getElementById('notification');
    const notificationText = document.getElementById('notificationText');
    
    if (notification && notificationText) {
        notificationText.textContent = message;
        notification.classList.add('show');
        
        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }
}

// Settings
function openSettings() {
    const modal = document.getElementById('settingsModal');
    if (modal) modal.classList.add('active');
    
    // Load current values
    const apiKeyInput = document.getElementById('geminiApiKey');
    if (apiKeyInput) apiKeyInput.value = Config.apiKey || '';
    
    const wakeWordInput = document.getElementById('wakeWord');
    if (wakeWordInput) wakeWordInput.value = Config.voice.wakeWord || 'হ্যালো নেক্সাস';
    
    // Update language select
    const langSelect = document.getElementById('languageSelect');
    if (langSelect) langSelect.value = AppState.currentLanguage;
}

function closeSettings() {
    const modal = document.getElementById('settingsModal');
    if (modal) modal.classList.remove('active');
}

function saveSettings() {
    const apiKeyInput = document.getElementById('geminiApiKey');
    const wakeWordInput = document.getElementById('wakeWord');
    const langSelect = document.getElementById('languageSelect');
    
    if (apiKeyInput) {
        Config.apiKey = apiKeyInput.value;
        if (window.aiCore) window.aiCore.setApiKey(apiKeyInput.value);
    }
    if (wakeWordInput) Config.voice.wakeWord = wakeWordInput.value;
    if (langSelect) {
        Config.voice.language = langSelect.value;
        AppState.currentLanguage = langSelect.value;
        if (window.aiCore) window.aiCore.setLanguage(langSelect.value);
    }
    
    Config.save();
    
    showNotification('Settings saved! ✓');
    closeSettings();
}

// Capture Screen
function captureScreen() {
    showNotification('Capturing screen...');
    // Screen capture implementation
}

// Volume
document.addEventListener('DOMContentLoaded', () => {
    const volumeSlider = document.getElementById('volumeSlider');
    const volumeValue = document.getElementById('volumeValue');
    
    if (volumeSlider && volumeValue) {
        volumeSlider.addEventListener('input', (e) => {
            volumeValue.textContent = e.target.value + '%';
            if (window.voiceSynthesis) {
                window.voiceSynthesis.setVolume(e.target.value / 100);
            }
        });
    }
});

// Voice Recognition Handler
if (window.voiceRecognition) {
    window.voiceRecognition.onResult = (result) => {
        if (result.isFinal && result.final) {
            processVoiceInput(result.final);
        }
    };
}

// Export
window.App = {
    toggleListening,
    processVoiceInput,
    sendChatMessage,
    handleChatKeyPress,
    changeChatLanguage,
    generateImage,
    generatePDF,
    generateCode,
    translateText,
    speak,
    showNotification,
    addLogEntry,
    addChatMessage,
    updateStatus,
    updateNeuralStatus
};

// Also export individual functions for HTML onclick
window.sendChatMessage = sendChatMessage;
window.handleChatKeyPress = handleChatKeyPress;
window.changeChatLanguage = changeChatLanguage;
window.generateImage = generateImage;
window.generatePDF = generatePDF;
window.generateCode = generateCode;
window.translateText = translateText;